# Marchi propri — rimozione di ogni marchio di terzi

Due cose, non una.

**I loghi.** Coldiretti e Campagna Amica erano caricati come immagini e
mostrati in 13 punti. Sono stati sostituiti dai due marchi Campo Zero.

**I testi.** Erano il problema piu' grosso: l'applicazione si presentava
come se fosse Coldiretti. "Azienda Certificata Coldiretti", "il nostro
team Coldiretti", "la tua password e' gestita in sicurezza dal sistema
Coldiretti", "© Coldiretti" in fondo a otto pagine. Un logo si toglie in
un minuto; una frase che attribuisce a un ente una certificazione o una
responsabilita' e' un'affermazione di affiliazione, ed e' esattamente
cio' che il progetto dichiara di non fare. **81 stringhe** riscritte in
31 file.

---

## 1. Un componente al posto di tredici copie

I due marchi stavano scritti a mano, con l'URL completo, in tredici
file. Adesso stanno in un solo punto:

```
src/lib/marchi.js                 gli URL
src/components/shared/Marchi.jsx  il lockup
```

Chi lo usa scrive `<Marchi altezza={40} />`. Il prossimo cambio di
marchio e' una riga, non un giro di tredici file.

**Due versioni del marchio di progetto.** Il verde del lettering non ha
contrasto sui fondi scuri: su login e onboarding, e in tema scuro,
il componente passa da solo alla versione chiara. Campo Zero e' un tondo
su disco bianco e si legge ovunque: versione unica.

## 2. Cosa e' stato riscritto nei testi

| Prima | Adesso |
|---|---|
| © Coldiretti · Campagna Amica | © Campagna Amica Digital · Campo Zero |
| Azienda Certificata Coldiretti | Azienda del circuito |
| Listino Certificato Coldiretti | Listino prodotti |
| Benvenuto nel Network Coldiretti | Benvenuto nella rete |
| gestita dal sistema Coldiretti | gestita dal sistema |
| Il nostro team Coldiretti | Il nostro team |
| Mercati / mercato Coldiretti | Mercati / mercato |
| Inserisci il codice Coldiretti | Inserisci il codice di accesso |

Il footer adesso porta anche la dichiarazione di progetto indipendente.

## 3. Le notizie da coldiretti.it — da decidere

Due pagine chiedono all'AI di andare su `coldiretti.it` e riportare le
notizie. Citare la fonte e linkarla e' legittimo; **riprodurne il testo
no.** Il prompt ora chiede un riassunto riscritto con parole proprie
invece della descrizione originale, e il link all'articolo resta.

E' una riduzione del rischio, non un via libera: prelevare
sistematicamente contenuti da un sito terzo resta una cosa da far
verificare a un avvocato prima del pilot. Se la risposta e' no, la
funzione si spegne in due file.

## 4. Il nome

Togliere i loghi riduce l'esposizione; **non la azzera.** "Campagna
Amica" e' una denominazione di Coldiretti, e resta nel nome del
progetto, nel dominio e nel marchio nuovo. E' una scelta tua e ha senso
commercialmente — ma va messa sul tavolo con l'avvocato insieme al
deposito del marchio Campo Zero, non lasciata implicita.

---

## 5. Come applicarlo

**Passo 1 — carica i tre loghi.** Sono in `loghi/`. Dalla radice del
repo, con la service role key del progetto `campagna-amica-unificato`
(Supabase → Project Settings → API → `service_role`):

```bash
read -rsp "service role key: " SRK && echo
for f in campo-zero.png campagna-amica-digital.png campagna-amica-digital-chiaro.png; do
  echo -n "$f -> "
  curl -s -o /dev/null -w "%{http_code}\n" -X POST \
    "https://otefhryrnajzfyaiwmja.supabase.co/storage/v1/object/public-assets/marchi/$f" \
    -H "Authorization: Bearer $SRK" -H "Content-Type: image/png" \
    --data-binary "@loghi/$f"
done
```

`200` per tutti e tre.

**Passo 2 — togli i loghi altrui dallo Storage.** Non basta non
mostrarli: finche' sono nel bucket pubblico restano pubblicati.

```bash
for f in coldiretti.png campagna-amica.jpeg; do
  echo -n "$f -> "
  curl -s -o /dev/null -w "%{http_code}\n" -X DELETE \
    "https://otefhryrnajzfyaiwmja.supabase.co/storage/v1/object/public-assets/marchi/$f" \
    -H "Authorization: Bearer $SRK"
done
unset SRK
```

**Passo 3 — estrai il pacchetto** nella radice del repo (37 file).

**Passo 4 — verifica.**

```bash
npx tsc --noEmit && npm run build 2>&1 | tail -2
grep -rn "coldiretti\|media.base44.com" src/ --include=*.jsx --include=*.ts -i | grep -v "coldiretti.it"
```

La seconda riga non deve stampare nulla. Quello che resta con
`coldiretti.it` e' la fonte delle notizie del punto 3.

**Passo 5 — guarda l'app**, in tema chiaro e in tema scuro: login,
home, un dettaglio azienda, il drawer profilo.

## 6. Un controllo in CI, da aggiungere

Nel `ci.yml` del pacchetto repo, accanto al controllo su `base44`:

```yaml
      - name: Nessun marchio di terzi nell'interfaccia
        run: |
          if grep -rniE "coldiretti" src/ --include=*.jsx --include=*.ts \
             | grep -v "coldiretti\.it"; then
            echo "::error::riferimento a un marchio di terzi in src/"
            exit 1
          fi
```

Cosi' non rientra dalla finestra al prossimo copia-incolla da Base44.
